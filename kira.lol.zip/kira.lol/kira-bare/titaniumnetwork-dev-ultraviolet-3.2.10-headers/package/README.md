<p align="center"><img src="https://raw.githubusercontent.com/titaniumnetwork-dev/Ultraviolet-Static/main/public/uv.png" height="250"></p>

<h1 align="center">Ultraviolet</h1>

<a href="https://www.npmjs.com/package/@titaniumnetwork-dev/ultraviolet"><img src="https://img.shields.io/npm/v/@titaniumnetwork-dev/ultraviolet.svg?maxAge=3600" alt="npm version" /></a>

> [!CAUTION]
> Please note that this project isn't really maintained anymore before making issues! It has been superseded by [Scramjet](https://github.com/MercuryWorkshop/scramjet). An example application setup can be found [here](https://github.com/MercuryWorkshop/Scramjet-App).

Ultraviolet is a highly advanced web proxy used for evading internet censorship or accessing websites in a controlled sandbox. It is designed with security and performance in mind. Ultraviolet intercepts HTTP requests with a service worker, while adhering to the [TompHTTP specifications](https://github.com/tomphttp) and is a leader in innovative web proxy technologies.

## Features

Ultraviolet offers several features that set it apart from its predecessors, including CAPTCHA and hCAPTCHA support, URL encoding settings for added security, client-side configuration via service-workers, high speed compared to other web proxies, blacklist settings and more for easy hosting, leak prevention, regular updates, and improved resource usage and speed for better setups with a dedicated server instance.

## Supported Sites

Some of the popular websites that Ultraviolet supports include:

- [Google](https://google.com)
- [Youtube](https://www.youtube.com)
- [Spotify](https://spotify.com)
- [Discord](https://discord.com)
- [Reddit](https://reddit.com)
- [GeForce NOW](https://play.geforcenow.com/)
- [now.gg](https://now.gg)

## Used by

- [Holy Unblocker LTS](https://github.com/QuiteAFancyEmerald/Holy-Unblocker)
- [Alu](https://github.com/titaniumnetwork-dev/Alu)
- [Incognito](https://github.com/titaniumnetwork-dev/Incognito)
- [Nebula](https://github.com/NebulaServices/Nebula)
- [AnuraOS](https://github.com/MercuryWorkshop/anuraOS)
- [Terbium](https://github.com/TerbiumOS/webOS)
- [Metallic](https://github.com/Metallic-Web/Metallic)

## Upgrading

A guide for updating from any version to v3 can be found [here](https://github.com/titaniumnetwork-dev/Ultraviolet/wiki/Upgrading).

## Older Ultraviolet versions

Starting from v3, Ultraviolet uses [bare-mux](https://github.com/MercuryWorkshop/bare-mux), a library that allows you to switch out your Bare client.

If you operate using an older Ultraviolet, we encourage you to update.

If you're too lazy to do either of the above, you can install an outdated and unsupported version of Ultraviolet.

```sh
npm install @titaniumnetwork-dev/ultraviolet@1
```

## Changelog

Changes are documented in the [changelog](./CHANGELOG.md).

## Deployment

This repository can be built, but it can't be deployed to any services. See [Ultraviolet-App](https://github.com/titaniumnetwork-dev/Ultraviolet-App) for a complete and customizable Ultraviolet setup that you can deploy.

## Documentation

Documentation can be found in the [wiki](https://github.com/titaniumnetwork-dev/Ultraviolet/wiki).
